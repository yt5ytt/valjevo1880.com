<?php
$db_users = new mysqli("localhost", "hasa0218_admin", "sna2405976", "hasa0218_centarplus");
$db_admin = new mysqli ("localhost", "hasa0218_admin", "sna2405976", "hasa0218_centarplus");
?>