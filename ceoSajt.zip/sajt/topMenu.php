<?php
?>
<menu>
  <ul>
    <li><a href="../index.php">Naslovna</a></li>
    <li><a href="oNama.php">O nama</a></li>
    <li><a href="vesti.php">Vesti</a></li>
    <li><a href="rezultati.php">Rezultati</a></li>
    <li><a href="kontakt.php">Kontakt</a></li>
  </ul>
</menu>
<?php
 ?>
