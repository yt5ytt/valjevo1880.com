<?php
?>
  <footer>
    <div class="links">
      <div class="korisniLinkovi">
        <h2><u>Korisni linkovi</u></h2>
        <a href="http://www.serbianshooting.rs/">Streljački savez Srbije</a><br />
        <a href="http://www.issf-sports.org/">Međunarodna streljačka federacija</a><br />
        <a href="http://www.bgshooting.org.rs/">Streljački savez Beograda</a><br />
        <a href="http://www.kpsp.rs/">SK Partizan</a><br />
        <a href="http://sk-trofej.rs/">SK Novi Beograd - Ušće</a><br />
        <a href="http://sk-trofej.rs/">SK Trofej</a><br />
        <a href="http://www.mus.co.rs/">SK Muš</a><br />
      </div>
      <div class="kontakt">
        <h2><u>Kontaktirajte nas</u></h2>
        <a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/streljackiklub.valjevo">Facebook</a><br />
        <a href="mailto:">Pošaljite mail</a><br />
        <a href="#">066291292</a>
      </div>
      <div class="mapa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d868.2883687285939!2d19.897144684080125!3d44.27425478856591!2m3!1f4.743777452415851!2f0!3f0!3m2!1i1024!2i768!4f35!3m3!1m2!1s0x4759ed9886934b0f%3A0xd5155254740ffb1!2sSK+Centar+Plus!5e1!3m2!1ssr!2srs!4v1523012230826" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
    </div>
    <div class="copyright">
      Designed by <a href="http://alexwebsoft.net"><b>AlexWebSoft</b></a> &copy 2018. - All rights reserved.
    </div>
  </footer>
<?php
 ?>
